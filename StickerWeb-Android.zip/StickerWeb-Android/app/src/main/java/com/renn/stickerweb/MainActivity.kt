package com.renn.stickerweb

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        // >>> GANTI dengan domain webmu (tanpa slash di akhir) <<<
        const val START_URL = "https://rendyyy.web.id"
        private const val REQ_ADD_PACK = 200
        private const val MAX_ZIP = 40 * 1024 * 1024
    }

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "StickerApp")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == Uri.parse(START_URL).host) return false
                startActivity(Intent(Intent.ACTION_VIEW, request.url)) // link luar -> browser
                return true
            }
        }
        web.loadUrl(START_URL)
    }

    inner class Bridge {
        /** Dipanggil dari JS: StickerApp.addPack('{"urls":[...],"title":"..","author":".."}') */
        @JavascriptInterface
        fun addPack(bodyJson: String) {
            thread {
                try {
                    val c = URL("$START_URL/api/pack").openConnection() as HttpURLConnection
                    c.connectTimeout = 15_000
                    c.readTimeout = 120_000
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.outputStream.use { it.write(bodyJson.toByteArray()) }

                    if (c.responseCode != 200) {
                        val err = c.errorStream?.readBytes()?.let { String(it) } ?: ""
                        val msg = runCatching { JSONObject(err).getString("error") }.getOrDefault("Server error ${c.responseCode}")
                        return@thread notify(false, msg)
                    }
                    val out = ByteArrayOutputStream()
                    c.inputStream.use { ins ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            if (out.size() > MAX_ZIP) error("Pack terlalu besar")
                        }
                    }
                    val pack = PackStore.importZip(this@MainActivity, out.toByteArray())
                    runOnUiThread { launchWhatsApp(pack) }
                    notify(true, "")
                } catch (t: Throwable) {
                    notify(false, t.message ?: "Gagal memproses pack")
                }
            }
        }
    }

    private fun launchWhatsApp(pack: Pack) {
        val i = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").apply {
            putExtra("sticker_pack_id", pack.id)
            putExtra("sticker_pack_authority", "$packageName.stickercontentprovider")
            putExtra("sticker_pack_name", pack.name)
        }
        try {
            startActivityForResult(i, REQ_ADD_PACK)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "WhatsApp belum terpasang / versinya terlalu lama", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ADD_PACK && resultCode == RESULT_CANCELED) {
            val err = data?.getStringExtra("validation_error")
            if (err != null) Toast.makeText(this, "WhatsApp menolak pack: $err", Toast.LENGTH_LONG).show()
        }
    }

    private fun notify(ok: Boolean, msg: String) {
        runOnUiThread { web.evaluateJavascript("window.onWaResult&&window.onWaResult(${JSONObject.quote(msg)},$ok)", null) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
