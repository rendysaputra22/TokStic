package com.renn.stickerweb

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

data class Sticker(val file: String, val emoji: String)
data class Pack(
    val id: String,
    val name: String,
    val publisher: String,
    val tray: String,
    val animated: Boolean,
    val stickers: List<Sticker>
)

object PackStore {
    private const val MAX_PACKS = 20

    fun root(ctx: Context): File = File(ctx.filesDir, "packs").apply { mkdirs() }

    /** Ekstrak zip hasil /api/pack ke folder internal app. */
    fun importZip(ctx: Context, zip: ByteArray): Pack {
        val id = "pack_" + System.currentTimeMillis()
        val dir = File(root(ctx), id).apply { mkdirs() }
        var title = "Stickers"
        var author = "Sticker Web"
        var animated = false
        val webps = mutableListOf<String>()
        try {
            ZipInputStream(ByteArrayInputStream(zip)).use { zis ->
                var e = zis.nextEntry
                while (e != null) {
                    val name = File(e.name).name // buang path -> aman dari zip-slip
                    if (!e.isDirectory && name.isNotEmpty()) {
                        val data = zis.readBytes()
                        when {
                            name == "title.txt" -> title = String(data).trim().take(60)
                            name == "author.txt" -> author = String(data).trim().take(60)
                            name == "meta.json" -> animated = JSONObject(String(data)).optBoolean("animated")
                            name == "tray.png" -> File(dir, name).writeBytes(data)
                            name.endsWith(".webp") -> { File(dir, name).writeBytes(data); webps += name }
                        }
                    }
                    e = zis.nextEntry
                }
            }
            if (!File(dir, "tray.png").exists()) error("Tray icon tidak ada")
            if (webps.size !in 3..30) error("Jumlah stiker harus 3-30 (dapat ${webps.size})")
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        }
        webps.sortBy { it.removeSuffix(".webp").toIntOrNull() ?: 0 }
        val pack = Pack(id, title, author, "tray.png", animated, webps.map { Sticker(it, "😀") })
        File(dir, "pack.json").writeText(toJson(pack).toString())
        trim(ctx)
        return pack
    }

    fun loadAll(ctx: Context): List<Pack> =
        (root(ctx).listFiles() ?: emptyArray())
            .filter { File(it, "pack.json").exists() }
            .sortedBy { it.name }
            .mapNotNull { runCatching { fromJson(JSONObject(File(it, "pack.json").readText())) }.getOrNull() }

    private fun trim(ctx: Context) {
        val dirs = (root(ctx).listFiles() ?: return).sortedBy { it.name }
        dirs.dropLast(MAX_PACKS).forEach { it.deleteRecursively() }
    }

    private fun toJson(p: Pack) = JSONObject().apply {
        put("id", p.id); put("name", p.name); put("publisher", p.publisher)
        put("tray", p.tray); put("animated", p.animated)
        put("stickers", JSONArray().also { a ->
            p.stickers.forEach { a.put(JSONObject().put("file", it.file).put("emoji", it.emoji)) }
        })
    }

    private fun fromJson(j: JSONObject): Pack {
        val arr = j.getJSONArray("stickers")
        return Pack(
            j.getString("id"), j.getString("name"), j.getString("publisher"),
            j.getString("tray"), j.optBoolean("animated"),
            (0 until arr.length()).map { arr.getJSONObject(it).let { s -> Sticker(s.getString("file"), s.getString("emoji")) } }
        )
    }
}
