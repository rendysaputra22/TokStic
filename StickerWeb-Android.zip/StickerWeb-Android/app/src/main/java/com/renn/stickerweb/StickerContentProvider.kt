package com.renn.stickerweb

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File

/** Implementasi kontrak resmi WhatsApp Stickers (github.com/WhatsApp/stickers). */
class StickerContentProvider : ContentProvider() {

    private lateinit var authority: String
    private lateinit var matcher: UriMatcher

    private companion object {
        const val METADATA = 1
        const val METADATA_ONE = 2
        const val STICKERS = 3
        const val ASSET = 4
    }

    override fun onCreate(): Boolean {
        authority = context!!.packageName + ".stickercontentprovider"
        matcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(authority, "metadata", METADATA)
            addURI(authority, "metadata/*", METADATA_ONE)
            addURI(authority, "stickers/*", STICKERS)
            addURI(authority, "stickers_asset/*/*", ASSET)
        }
        return true
    }

    override fun query(
        uri: Uri, projection: Array<String>?, selection: String?,
        selectionArgs: Array<String>?, sortOrder: String?
    ): Cursor {
        val packs = PackStore.loadAll(context!!)
        return when (matcher.match(uri)) {
            METADATA -> metaCursor(packs)
            METADATA_ONE -> metaCursor(packs.filter { it.id == uri.lastPathSegment })
            STICKERS -> stickerCursor(packs.firstOrNull { it.id == uri.lastPathSegment })
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
    }

    private fun metaCursor(packs: List<Pack>): Cursor {
        val c = MatrixCursor(
            arrayOf(
                "sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher",
                "sticker_pack_icon", "android_play_store_link", "ios_app_download_link",
                "sticker_pack_publisher_email", "sticker_pack_publisher_website",
                "sticker_pack_privacy_policy_website", "sticker_pack_license_agreement_website",
                "image_data_version", "whatsapp_will_not_cache_stickers", "animated_sticker_pack"
            )
        )
        packs.forEach {
            c.addRow(arrayOf<Any>(it.id, it.name, it.publisher, it.tray, "", "", "", "", "", "", "1", 0, if (it.animated) 1 else 0))
        }
        c.setNotificationUri(context!!.contentResolver, uri(""))
        return c
    }

    private fun stickerCursor(p: Pack?): Cursor {
        val c = MatrixCursor(arrayOf("sticker_file_name", "sticker_emoji"))
        p?.stickers?.forEach { c.addRow(arrayOf<Any>(it.file, it.emoji)) }
        c.setNotificationUri(context!!.contentResolver, uri(""))
        return c
    }

    private fun uri(path: String) = Uri.parse("content://$authority/$path")

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        if (matcher.match(uri) != ASSET) return null
        val seg = uri.pathSegments
        if (seg.size != 3) return null
        val root = PackStore.root(context!!)
        val f = File(File(root, seg[1]), seg[2])
        if (!f.canonicalPath.startsWith(root.canonicalPath) || !f.isFile) return null
        return AssetFileDescriptor(
            ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY),
            0, AssetFileDescriptor.UNKNOWN_LENGTH
        )
    }

    override fun getType(uri: Uri): String? = when (matcher.match(uri)) {
        METADATA -> "vnd.android.cursor.dir/vnd.$authority.metadata"
        METADATA_ONE -> "vnd.android.cursor.item/vnd.$authority.metadata"
        STICKERS -> "vnd.android.cursor.dir/vnd.$authority.stickers"
        ASSET -> if (uri.lastPathSegment?.endsWith(".png") == true) "image/png" else "image/webp"
        else -> throw IllegalArgumentException("Unknown URI: $uri")
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException()
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int = throw UnsupportedOperationException()
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<String>?): Int =
        throw UnsupportedOperationException()
}
