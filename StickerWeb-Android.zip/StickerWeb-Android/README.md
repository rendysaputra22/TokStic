# TokStic (wrapper Android)

1. Buka `app/src/main/java/com/renn/stickerweb/MainActivity.kt`, `START_URL` sudah diset ke https://rendyyy.web.id.
2. Build APK:
   - **Android Studio**: File > Open folder ini > Build > Build APK(s). (Studio akan minta/unduh Gradle sendiri.)
   - **GitHub Actions**: push folder ini ke repo, tab Actions > Build APK > Run, unduh artifact `app-debug.apk`.
3. Install APK, buka, scan link TikTok, pilih stiker (min 3), buka "Add Stickers +", tekan **Add to WhatsApp**.
